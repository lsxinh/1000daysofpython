# PyXYZ
Some small python scripts to handle XYZ files

Tutorial:
Spatial Python S 1 1 https://youtu.be/V5ChiUz7-5I
Spatial Python S 1 2 https://youtu.be/CsdIlxRmcjg


#SpatialPython #pyXYZ #XLGEO

